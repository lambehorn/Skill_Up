let express = require(`express`);
const app = express();
const port = 3000;

app.listen(port, function () {
  console.log(`http://localhost:${port}`);
});
app.use(express.static(`public`));

const hbs = require(`hbs`);
app.set(`views`, `views`);
app.set(`view engine`, `hbs`);

 
app.get("/", function (req, res) {
  res.render("main");
}); 

app.get("/hf", function (req, res) {
  res.render("head_and_footer");
});  